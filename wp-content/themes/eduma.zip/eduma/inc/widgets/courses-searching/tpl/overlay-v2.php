<?php
echo 'This widget has not supported LearnPress 2.0 yet. The update of the theme will be released soon.';