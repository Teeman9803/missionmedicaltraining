<?php
$footer = $titan->createThimCustomizerSection( array(
	'name'     => esc_html__( 'Footer', 'eduma' ),
	'position' => 35,
	'id'       => 'display_footer'
) );
