<?php

$courses = $titan->createThimCustomizerSection( array(
	'name'     => esc_html__('Events', 'eduma'),
	'position' => 75,
	'id'       => 'event',
) );
