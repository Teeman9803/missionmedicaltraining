<?php

$courses = $titan->createThimCustomizerSection( array(
	'name'     => esc_html__('Portfolio', 'eduma'),
	'position' => 75,
	'id'       => 'portfolio',
) );
