<?php

$display = $titan->createThimCustomizerSection( array(
	'name'     => esc_html__( 'Display', 'eduma' ),
	'position' => 45,
	'id'       => 'display',
) );