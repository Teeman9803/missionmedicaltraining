<?php

$woocommerce = $titan->createThimCustomizerSection( array(
	'name'     => esc_html__( 'WooCommerce', 'eduma' ),
	'position' => 70,
	'id'       => 'woocommerce',
) );