<?php
/*
 * Creating a Styling Options
 */

$styling = $titan->createThimCustomizerSection( array(
	'name'     => esc_html__( 'Styling', 'eduma' ),
	'position' => 40,
	'id'       => 'styling'
) );

