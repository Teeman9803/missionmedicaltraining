<?php
$page_builder = $titan->createThimCustomizerSection( array(
	'name'     => esc_html__( 'Page Builder', 'eduma' ),
	'position' => 40,
	'id'       => 'page_builder'
) );
