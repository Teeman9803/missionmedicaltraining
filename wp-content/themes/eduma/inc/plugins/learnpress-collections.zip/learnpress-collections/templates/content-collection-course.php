<?php
learn_press_get_template('content-course.php');