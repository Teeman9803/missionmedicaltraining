//version 1.5 27/01/2016
+ Update upload option to support svg format.(class-option-upload.php)

//version 1.6 03/02/2016
+ Improved import function.

//version 1.7 19/02/2016
+ Fixed required import demo.
+ Updated class Thim_Widget

//version 1.9.6 19/02/2016
+ Made metabox settings filterable.

//version 1.9.7 14/07/2016
+ Update font awesome to v4.6.3.
+ Fixed conflict with page gravity form on admin.