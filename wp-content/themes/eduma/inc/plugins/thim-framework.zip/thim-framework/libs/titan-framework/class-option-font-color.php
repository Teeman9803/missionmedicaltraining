<?php
/**
 * Font Option Class
 *
 * @since    1.4
 */

if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Font Option Class
 *
 * @since    1.4
 */
class TitanFrameworkOptionFontColor extends TitanFrameworkOption {

	// Default settings specific to this option
	public $defaultSecondarySettings = array(
		'show_font_family'    => true,
		'show_color'          => true,
		'show_font_size'      => true,
		'show_font_weight'    => true,
		'show_font_style'     => true,
		'show_line_height'    => true,
		'show_letter_spacing' => true,
		'show_text_transform' => true,
		'show_font_variant'   => true,
		'show_text_shadow'    => true,
		'show_preview'        => true,
		'enqueue'             => true,
		'preview_text'        => '',
		'include_fonts'       => '', // A regex string or array of regex strings to match font names to include.
		'show_websafe_fonts'  => true,
		'show_google_fonts'   => true,
	);

	// Default style options
	public static $defaultStyling = array(
		'font-family'          => 'Open Sans',
		'color-opacity'        => '#333333',
		'font-size'            => '13px',
		'font-weight'          => 'normal',
		'font-style'           => 'normal',
		'line-height'          => '1.5em',
		'letter-spacing'       => 'normal',
		'text-transform'       => 'none',
		'font-variant'         => 'normal',
		'text-shadow-location' => 'none',
		'text-shadow-distance' => '0px',
		'text-shadow-blur'     => '0px',
		'text-shadow-color'    => '#333333',
		'text-shadow-opacity'  => '1',
		'font-type'            => 'google', // Only used internally to determine if the font is a
		'dark'                 => '', // only used to toggle the preview background
	);

	// The list of web safe fonts
	public static $webSafeFonts = array(
		'Arial, Helvetica, sans-serif'                         => 'Arial',
		'"Arial Black", Gadget, sans-serif'                    => 'Arial Black',
		'"Comic Sans MS", cursive, sans-serif'                 => 'Comic Sans',
		'"Courier New", Courier, monospace'                    => 'Courier New',
		'Georgia, serif'                                       => 'Geogia',
		'Impact, Charcoal, sans-serif'                         => 'Impact',
		'"Lucida Console", Monaco, monospace'                  => 'Lucida Console',
		'"Lucida Sans Unicode", "Lucida Grande", sans-serif'   => 'Lucida Sans',
		'"Palatino Linotype", "Book Antiqua", Palatino, serif' => 'Palatino',
		'Tahoma, Geneva, sans-serif'                           => 'Tahoma',
		'"Times New Roman", Times, serif'                      => 'Times New Roman',
		'"Trebuchet MS", Helvetica, sans-serif'                => 'Trebuchet',
		'Verdana, Geneva, sans-serif'                          => 'Verdana',
	);

	// Holds all the Google Fonts for enqueuing
	private static $googleFontsOptions = array();

	private static $firstLoad = true;


	/**
	 * Constructor
	 *
	 * @return    void
	 * @since    1.4
	 */
	function __construct( $settings, $owner ) {
		parent::__construct( $settings, $owner );
		add_action( 'admin_enqueue_scripts', array( $this, "loadAdminScripts" ) );
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'loadAdminScripts' ) );
		add_action( 'admin_head', array( __CLASS__, 'createFontScript' ) );
		add_action( 'tf_create_option_' . $this->getOptionNamespace(), array( $this, "rememberGoogleFonts" ) );
		add_action( 'wp_enqueue_scripts', array( $this, "enqueueGooglefonts" ) );
		add_filter( 'tf_generate_css_font_' . $this->getOptionNamespace(), array( $this, 'generateCSS' ), 10, 2 );
	}


	/**
	 * Keeps track of all the Google Fonts used for enqueueing later in wp_enqueue_scripts
	 *
	 * @param    TitanFramework $option The option being enqueued
	 *
	 * @return    void
	 * @since    1.4
	 */
	public function rememberGoogleFonts( $option ) {
		if ( is_a( $option, __CLASS__ ) ) {
			if ( $option->settings['enqueue'] ) {
				self::$googleFontsOptions[] = $option;
			}
		}
	}


	/**
	 * Enqueues all the Google fonts, used in wp_enqueue_scripts
	 *
	 * @return    void
	 * @since    1.4
	 */
	public function enqueueGooglefonts() {
		if ( !count( self::$googleFontsOptions ) ) {
			return;
		}

		// Gather all the fonts that we need to load, some may be repeated so we need to
		// load them once after gathering them
		$fontsToLoad = array();

		foreach ( self::$googleFontsOptions as $option ) {
			$fontValue = $option->getFramework()->getOption( $option->settings['id'] );

			if ( empty( $fontValue['font-family'] ) ) {
				continue;
			}

			if ( $fontValue['font-type'] != 'google' ) {
				continue;
			}


			// Get all the fonts that we need to load
			if ( empty( $fontsToLoad[$fontValue['font-family']] ) ) {
				$fontsToLoad[$fontValue['font-family']] = array();
			}

			// Get the weight
			$variant = $fontValue['font-weight'];
			if ( $variant == 'normal' ) {
				$variant = '400,700';
			} else if ( $variant == 'bold' ) {
				$variant = '500';
			} else if ( $variant == 'bolder' ) {
				$variant = '800';
			} else if ( $variant == 'lighter' ) {
				$variant = '100';
			} else if ( $variant == '300' ) {
				$variant = '300';
			}

			if ( $fontValue['font-style'] == 'italic' ) {
				$variant .= 'italic';
			}

			$fontsToLoad[$fontValue['font-family']][] = $variant;
		}
		$list = titan_get_googlefonts();

		// Enqueue the Google Font
		foreach ( $fontsToLoad as $fontName => $value ) {

			$variants = array( 400 );
			$subsets  = array( 'latin', 'latin-ext' );
			foreach ( $list as $font ) {
				if ( isset( $font['name'] ) && $font['name'] == $fontName ) {
					$variants = $font['variants'];
					$subsets  = $font['subsets'];
				}
			}

			$fontUrl = sprintf( "//fonts.googleapis.com/css?family=%s:%s&subset=%s",
				str_replace( ' ', '+', $fontName ),
				implode( ',', $variants ),
				implode( ',', $subsets )
			);

			wp_enqueue_style( 'tf-google-webfont-' . strtolower( str_replace( ' ', '-', $fontName ) ), $fontUrl );
		}

		// Don't repeat
		self::$googleFontsOptions = array();
	}


	/**
	 * Generates CSS for the font, this is used in TitanFrameworkCSS
	 *
	 * @param    string               $css    The CSS generated
	 * @param    TitanFrameworkOption $option The current option being processed
	 *
	 * @return    string The CSS generated
	 * @since    1.4
	 */
	public function generateCSS( $css, $option ) {
		if ( $this->settings['id'] != $option->settings['id'] ) {
			return $css;
		}

		$value = $this->getFramework()->getOption( $option->settings['id'] );

		$skip = array( 'dark', 'font-type', 'text-shadow-distance', 'text-shadow-blur', 'text-shadow-color', 'text-shadow-opacity' );

		// If the value is blank, use the defaults
		if ( empty( $value ) ) {
			$value = $this->getValue();
			if ( is_serialized( $value ) ) {
				$value = unserialize( $value );
			}
			if ( !is_array( $value ) ) {
				$value = array();
			}
			$value = array_merge( self::$defaultStyling, $value );
		}

		foreach ( $value as $key => $val ) {
			// Force skip other keys, those are processed under another key, e.g. text-shadow-distance is
			// used by text-shadow-location
			if ( in_array( $key, $skip ) ) {
				continue;
			}
			// Don't include keys which are not in the default styles
			if ( !in_array( $key, array_keys( self::$defaultStyling ) ) ) {
				continue;
			}

			if ( $key == 'font-family' ) {
				if ( !empty( $value['font-type'] ) ) {
					if ( $value['font-type'] == 'google' ) {
						$css .= "\$" . $option->settings['id'] . "-" . $key . ": \"" . $value[$key] . "\";";
						continue;
					}
				}
				$css .= "\$" . $option->settings['id'] . "-" . $key . ": " . $value[$key] . ";";
				continue;
			}

			if ( $key == 'text-shadow-location' ) {
				$textShadow = '';
				if ( $value[$key] != 'none' ) {
					if ( stripos( $value[$key], 'left' ) !== false ) {
						$textShadow .= '-' . $value['text-shadow-distance'];
					} else if ( stripos( $value[$key], 'right' ) !== false ) {
						$textShadow .= $value['text-shadow-distance'];
					} else {
						$textShadow .= '0';
					}
					$textShadow .= ' ';
					if ( stripos( $value[$key], 'top' ) !== false ) {
						$textShadow .= '-' . $value['text-shadow-distance'];
					} else if ( stripos( $value[$key], 'bottom' ) !== false ) {
						$textShadow .= $value['text-shadow-distance'];
					} else {
						$textShadow .= '0';
					}
					$textShadow .= ' ';
					$textShadow .= $value['text-shadow-blur'];
					$textShadow .= ' ';

					$rgb   = tf_hex2rgb( $value['text-shadow-color'] );
					$rgb[] = $value['text-shadow-opacity'];

					$textShadow .= 'rgba(' . implode( ',', $rgb ) . ')';
				} else {
					$textShadow .= $value[$key];
				}

				$css .= "\$" . $option->settings['id'] . "-text-shadow: " . $textShadow . ";";
				continue;
			}

			$css .= "\$" . $option->settings['id'] . "-" . $key . ": " . $value[$key] . ";";
		}

		/*
		 * There are 2 ways to include the values for the CSS. The normal `value-arraykey`, or just `value`
		 * Using `value` will print out the entire font CSS
		 */

		// Create the entire CSS for the font, this should just be used to replace the `value` variable
		$cssVariables = '';
		$cssChecking  = array( 'font_family', 'color-opacity', 'font_size', 'font_weight', 'font_style', 'line_height', 'letter_spacing', 'text_transform', 'font_variant', 'text_shadow' );

		//Enter values that are not marked as false.
		foreach ( $cssChecking as $subject ) {
			if ( $option->settings['show_' . $subject] ) {
				$cssVariableArray[] = str_replace( "_", "-", $subject );
			}
		}

		//Now, integrate these values with their corresponding keys
		foreach ( $cssVariableArray as $param ) {
			$cssVariables .= $param . ": \$" . $option->settings['id'] . "-" . $param . ";\n";
		}

		// Replace the `value` parameters in the given css
		$modifiedCss = '';
		if ( !empty( $option->settings['css'] ) ) {
			$modifiedCss = $option->settings['css'];
			// if `value` is given, replace it with the entire css we created above in $cssVariables
			$modifiedCss = preg_replace( '/value[^-]/', $cssVariables, $modifiedCss );
			// normal `value-arraykey` values
			$modifiedCss = str_replace( 'value-', '$' . $option->settings['id'] . '-', $modifiedCss );
		}

		$css .= $modifiedCss;

		return $css;
	}


	/**
	 * Enqueues the needed scripts for the admin
	 *
	 * @return    void
	 * @since    1.4
	 */
	public function loadAdminScripts() {
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'chosen-admin-script', TP_THEME_FRAMEWORK_URI . 'js/chosen.jquery.min.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_style( 'chosen-admin-style', TP_THEME_FRAMEWORK_URI . 'css/chosen.css' );
	}


	/**
	 * Creates the Javascript for running the font option
	 *
	 * @return    void
	 * @since    1.4
	 */
	public static function createFontScript() {
		global $pagenow;

		if('customize.php' !=$pagenow){
			return;
		}

		if ( !self::$firstLoad ) {
			return;
		}
		self::$firstLoad = false;

		?>
		<script>
			jQuery(document).ready(function ($) {
				"use strict";

				var _tf_select_font_throttle = null;

				// Initialize color pickers
				Color.prototype.toString = function (remove_alpha) {
					if (remove_alpha == 'no-alpha') {
						return this.toCSS('rgba', '1').replace(/\s+/g, '');
					}
					if (this._alpha < 1) {
						return this.toCSS('rgba', this._alpha).replace(/\s+/g, '');
					}
					var hex = parseInt(this._color, 10).toString(16);
					if (this.error) return '';
					if (hex.length < 6) {
						for (var i = 6 - hex.length - 1; i >= 0; i--) {
							hex = '0' + hex;
						}
					}
					return '#' + hex;
				};

				jQuery('.color-picker-hex').each(function () {
					var $control = jQuery(this),
						value = $control.val().replace(/\s+/g, '');
					// Manage Palettes
					var palette_input = $control.attr('data-palette');
					if (palette_input == 'false' || palette_input == false) {
						var palette = false;
					} else if (palette_input == 'true' || palette_input == true) {
						var palette = true;
					} else {
						var palette = true;
						var palette = <?php global $primary_color; echo( $primary_color ? $primary_color : "true" ); ?>;
					}
					$control.wpColorPicker({ // change some things with the color picker
						clear   : function (event, ui) {
							// TODO reset Alpha Slider to 100
						},
						change  : function (event, ui) {

							if (!$control.hasClass("tf-font-sel-color")) {
								// send ajax request to wp.customizer to enable Save & Publish button
								var _new_value = ui.color.toString();
								var key = $control.attr('data-customize-setting-link');
								try {
									wp.customize(key, function (obj) {
										//console.log(_new_value+ " - " +ui.color);
										obj.set(_new_value);
									});
								} catch (err) {
									console.log(err);
								}
							} else {
								// update the preview, but throttle it to prevent fast loading
								if (_tf_select_font_throttle != null) {
									clearTimeout(_tf_select_font_throttle);
									_tf_select_font_throttle = null;
								}
								var $this = $(this);
								_tf_select_font_throttle = setTimeout(function () {
									tf_select_font_update_preview($this.parents('.tf-font:eq(0)'), true);
								}, 300);
							}

							// change the background color of our transparency container whenever a color is updated
							var $transparency = $control.parents('.wp-picker-container:first').find('.transparency');

							// we only want to show the color at 100% alpha
							$transparency.css('backgroundColor', ui.color.toString('no-alpha'));
						},
						palettes: palette // remove the color palettes
					});
					jQuery('<div class="thim-alpha-container"><div class="slider-alpha"></div><div class="transparency"></div></div>').appendTo($control.parents('.wp-picker-container').find(".wp-picker-holder"));
					var $alpha_slider = $control.parents('.wp-picker-container:first').find('.slider-alpha');
					// if in format RGBA - grab A channel value
					if (value.match(/rgba\(\d+\,\d+\,\d+\,([^\)]+)\)/)) {
						var alpha_val = parseFloat(value.match(/rgba\(\d+\,\d+\,\d+\,([^\)]+)\)/)[1]) * 100;
						var alpha_val = parseInt(alpha_val);
					} else {
						var alpha_val = 100;
					}
					$alpha_slider.slider({
						slide : function (event, ui) {
							jQuery(this).find('.ui-slider-handle').text(ui.value); // show value on slider handle
							// send ajax request to wp.customizer to enable Save & Publish button
							var _new_value = $control.val();
							var key = $control.attr('data-customize-setting-link');
							try {
								wp.customize(key, function (obj) {
									obj.set(_new_value);
								});
							}
							catch (err) {
								console.log(err);
							}

						},
						create: function (event, ui) {
							var v = jQuery(this).slider('value');
							jQuery(this).find('.ui-slider-handle').text(v);
						},
						value : alpha_val,
						range : "max",
						step  : 1,
						min   : 0,
						max   : 100
					}); // slider
					$alpha_slider.slider().on('slidechange', function (event, ui) {
						var new_alpha_val = parseFloat(ui.value),
							iris = $control.data('a8cIris'),
							color_picker = $control.data('wpWpColorPicker');
						iris._color._alpha = new_alpha_val / 100.0;
						$control.val(iris._color.toString());
						color_picker.toggler.css({
							backgroundColor: $control.val()
						});
						// fix relationship between alpha slider and the 'side slider not updating.
						var get_val = $control.val();
						jQuery($control).wpColorPicker('color', get_val);
					});
				}); // each

				// Initialize the option
				$('.tf-font').each(function () {

					// Update save field on change
					$(this).find('select,.tf-font-sel-dark').change(function () {
						tf_select_font_update_preview($(this).parents('.tf-font:eq(0)'), true);
					});

					// Trigger for toggling light/dark preview backgrounds
					$(this).find('.btn-dark').click(function () {
						var darkInput = $(this).parent().find('.tf-font-sel-dark');
						if (darkInput.val() == '') {
							darkInput.val('dark').trigger('change');
						} else {
							darkInput.val('').trigger('change');
						}
					})

					// initialize preview
					tf_select_font_update_preview($(this), true);

					// We have to do this after 1ms for the theme customizer, or else the field's value
					// gets changed to a weird value
					var $this = $(this);
					setTimeout(function () {
						tf_select_font_update_preview($this, false)
					}, 1);
				});

				$('body.wp-customizer').on('click', function (e) {
					$('.tf-font .wp-color-result').each(function () {
						if ($(this).hasClass('wp-picker-open')) {
							$(this).parents('label:eq(0)').addClass('tf-picker-open');
						} else {
							if ($(this).parents('label:eq(0)').hasClass('tf-picker-open')) {
								$(this).parents('label:eq(0)').removeClass('tf-picker-open');
							}
						}
					});
				});

				// chosen font
				$(".chosen-select").chosen({
					allow_single_deselect: true,
					width                : '60%'
				});
			});


			// Updates the option elements
			function tf_select_font_update_preview($container, doTrigger) {
				"use strict";
				var $ = jQuery;

				// Show / hide shadow fields
				if ($container.find(".tf-font-sel-location").val() == 'none'
					|| $container.find('.tf-font-sel-location').parents('label:eq(0)').attr('data-visible') == 'false') {
					$container.find(".tf-font-sel-distance").parents('label:eq(0)').fadeOut();
					$container.find(".tf-font-sel-blur").parents('label:eq(0)').fadeOut();
					$container.find(".tf-font-sel-shadow-color").parents('label:eq(0)').fadeOut();
					$container.find(".tf-font-sel-opacity").parents('label:eq(0)').fadeOut();
				} else {
					$container.find(".tf-font-sel-distance").parents('label:eq(0)').fadeIn();
					$container.find(".tf-font-sel-blur").parents('label:eq(0)').fadeIn();
					$container.find(".tf-font-sel-shadow-color").parents('label:eq(0)').fadeIn();
					$container.find(".tf-font-sel-opacity").parents('label:eq(0)').fadeIn();
				}

				var family = $container.find('.tf-font-sel-family').val();

				// These are all our parameters
				var params = {
					'font-family'         : family,
					'font-type'           : $container.find(".tf-font-sel-family option[value='" + family + "']").parent().attr('class'),
					'color-opacity'       : $container.find(".tf-font-sel-color").val(),
					'font-size'           : $container.find(".tf-font-sel-size").val(),
					'font-weight'         : $container.find(".tf-font-sel-weight").val(),
					'font-style'          : $container.find(".tf-font-sel-style").val(),
					'line-height'         : $container.find(".tf-font-sel-height").val(),
					'letter-spacing'      : $container.find(".tf-font-sel-spacing").val(),
					'text-transform'      : $container.find(".tf-font-sel-transform").val(),
					'font-variant'        : $container.find(".tf-font-sel-variant").val(),
					'text-shadow-location': $container.find(".tf-font-sel-location").val(),
					'text-shadow-distance': $container.find(".tf-font-sel-distance").val(),
					'text-shadow-blur'    : $container.find(".tf-font-sel-blur").val(),
					'text-shadow-color'   : $container.find(".tf-font-sel-shadow-color").val(),
					'text-shadow-opacity' : $container.find(".tf-font-sel-opacity").val(),
					'dark'                : $container.find(".tf-font-sel-dark").val(),
					'text'                : $container.find("iframe").attr('data-preview-text')
				}

				// Update preview
				if ($container.find('iframe').is(':not([data-visible=false])')) {
					$container.find('iframe').attr('src', '<?php echo TitanFramework::getURL( 'iframe-font-preview.php?', __FILE__ ) ?>' + $.param(params));
				}

				// Update hidden save field
				$container.find('.tf-for-saving').val(serialize(params));
				if (doTrigger) {
					$container.find('.tf-for-saving').trigger('change');
				}
			}
		</script>
		<?php
	}


	/**
	 * Displays the option in admin panels and meta boxes
	 *
	 * @return    void
	 * @since    1.4
	 */
	public function display() {
		$this->echoOptionHeader( true );

		// Get the current value and merge with defaults
		$value = $this->getValue();
		if ( is_serialized( $value ) ) {
			$value = unserialize( $value );
		}
		if ( !is_array( $value ) ) {
			$value = array();
		}
		$value = array_merge( self::$defaultStyling, $value );


		/*
		 * Create all the fields
		 */
		$visibilityAttrs = '';
		if ( !$this->settings['show_font_family'] ) {
			$visibilityAttrs = "data-visible='false' style='display: none'";
		}
		?>
		<div>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Font Family
				<select class='tf-font-sel-family chosen-select'>
					<?php
					if ( $this->settings['show_websafe_fonts'] ) {
						?>
						<optgroup label="Web Safe Fonts" class='safe'>
							<?php
							foreach ( self::$webSafeFonts as $family => $label ) {
								printf( "<option value='%s'%s>%s</option>",
									$family,
									selected( $value['font-family'], $family, false ),
									$label
								);
							}
							?>
						</optgroup>
						<?php
					}

					if ( $this->settings['show_google_fonts'] ) {
						?>
						<optgroup label="Google WebFonts" class='google'>
							<?php
							$allFonts = titan_get_googlefonts();
							foreach ( $allFonts as $key => $fontStuff ) {

								// Show only the include_fonts (font names) if provided, uses regex
								if ( !empty( $this->settings['include_fonts'] ) ) {
									if ( is_array( $this->settings['include_fonts'] ) ) {
										$fontNameMatch = false;
										foreach ( $this->settings['include_fonts'] as $fontNamePattern ) {
											if ( !is_string( $fontNamePattern ) ) {
												continue;
											}
											$fontNamePattern = '/' . trim( $fontNamePattern, '/' ) . '/';
											if ( preg_match( $fontNamePattern . 'i', $fontStuff['name'] ) ) {
												$fontNameMatch = true;
												break;
											}
										}
										if ( !$fontNameMatch ) {
											continue;
										}
									} else if ( is_string( $this->settings['include_fonts'] ) ) {
										$fontNamePattern = '/' . trim( $this->settings['include_fonts'], '/' ) . '/';
										if ( !preg_match( $fontNamePattern . 'i', $fontStuff['name'] ) ) {
											continue;
										}
									}
								}

								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $fontStuff['name'] ),
									selected( $value['font-family'], $fontStuff['name'], false ),
									$fontStuff['name']
								);
							}
							?>
						</optgroup>
						<?php
					}
					?>
				</select>
			</label>
			<?php


			$visibilityAttrs = '';
			if ( !$this->settings['show_color'] ) {
				$visibilityAttrs = "data-visible='false' style='display: none'";
			}
			?>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Color
				<input class='tf-font-sel-color color-picker-hex' type="text" value="<?php echo esc_attr( $value['color-opacity'] ) ?>" data-default-color="<?php echo esc_attr( $value['color-opacity'] ) ?>" />
			</label>
			<?php


			$visibilityAttrs = '';
			if ( !$this->settings['show_font_size'] ) {
				$visibilityAttrs = "data-visible='false' style='display: none'";
			}
			?>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Font Size
				<select class='tf-font-sel-size'>
					<?php
					for ( $i = 1; $i <= 150; $i ++ ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $i . 'px' ),
							selected( $value['font-size'], $i . 'px', false ),
							$i . 'px'
						);
					}
					?>
				</select>
			</label>
			<?php


			$visibilityAttrs = '';
			if ( !$this->settings['show_font_weight'] ) {
				$visibilityAttrs = "data-visible='false' style='display: none'";
			}
			?>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Font Weight
				<select class='tf-font-sel-weight'>
					<?php
					$options = array( 'normal', 'bold', 'bolder', 'lighter', '100', '200', '300', '400', '500', '600', '700', '800', '900' );
					foreach ( $options as $option ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $option ),
							selected( $value['font-weight'], $option, false ),
							$option
						);
					}
					?>
				</select>
			</label>
			<?php


			$visibilityAttrs = '';
			if ( !$this->settings['show_font_style'] ) {
				$visibilityAttrs = "data-visible='false' style='display: none'";
			}
			?>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Font Style
				<select class='tf-font-sel-style'>
					<?php
					$options = array( 'normal', 'italic' );
					foreach ( $options as $option ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $option ),
							selected( $value['font-style'], $option, false ),
							$option
						);
					}
					?>
				</select>
			</label>
			<?php


			$visibilityAttrs = '';
			if ( !$this->settings['show_line_height'] ) {
				$visibilityAttrs = "data-visible='false' style='display: none'";
			}
			?>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Line Height
				<select class='tf-font-sel-height'>
					<?php
					for ( $i = .5; $i <= 3; $i += 0.1 ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $i . 'em' ),
							selected( $value['line-height'], $i . 'em', false ),
							$i . 'em'
						);
					}
					?>
				</select>
			</label>
			<?php


			$visibilityAttrs = '';
			if ( !$this->settings['show_letter_spacing'] ) {
				$visibilityAttrs = "data-visible='false' style='display: none'";
			}
			?>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Letter Spacing
				<select class='tf-font-sel-spacing'>
					<option value='normal'>normal</option>
					<?php
					for ( $i = - 20; $i <= 20; $i ++ ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $i . 'px' ),
							selected( $value['letter-spacing'], $i . 'px', false ),
							$i . 'px'
						);
					}
					?>
				</select>
			</label>
			<?php


			$visibilityAttrs = '';
			if ( !$this->settings['show_text_transform'] ) {
				$visibilityAttrs = "data-visible='false' style='display: none'";
			}
			?>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Text Transform
				<select class='tf-font-sel-transform'>
					<?php
					$options = array( 'none', 'capitalize', 'uppercase', 'lowercase' );
					foreach ( $options as $option ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $option ),
							selected( $value['text-transform'], $option, false ),
							$option
						);
					}
					?>
				</select>
			</label>
			<?php


			$visibilityAttrs = '';
			if ( !$this->settings['show_font_variant'] ) {
				$visibilityAttrs = "data-visible='false' style='display: none'";
			}
			?>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Font Variant
				<select class='tf-font-sel-variant'>
					<?php
					$options = array( 'normal', 'small-caps' );
					foreach ( $options as $option ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $option ),
							selected( $value['font-variant'], $option, false ),
							$option
						);
					}
					?>
				</select>
			</label>
			<?php


			$visibilityAttrs = '';
			if ( !$this->settings['show_text_shadow'] ) {
				$visibilityAttrs = "data-visible='false' style='display: none'";
			}
			?>
			<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
				Shadow Location
				<select class='tf-font-sel-location'>
					<?php
					$options = array( 'none', 'top', 'bottom', 'left', 'right', 'top-left', 'top-right', 'bottom-left', 'bottom-right' );
					foreach ( $options as $option ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $option ),
							selected( $value['text-shadow-location'], $option, false ),
							$option
						);
					}
					?>
				</select>
			</label>
			<label style='display: none'>
				Shadow Distance
				<select class='tf-font-sel-distance'>
					<?php
					for ( $i = 0; $i <= 10; $i ++ ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $i . 'px' ),
							selected( $value['text-shadow-distance'], $i . 'px', false ),
							$i . 'px'
						);
					}
					?>
				</select>
			</label>
			<label style='display: none'>
				Shadow Blur
				<select class='tf-font-sel-blur'>
					<?php
					$options = array( '0px', '1px', '2px', '3px', '4px', '5px', '10px', '20px' );
					foreach ( $options as $option ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $option ),
							selected( $value['text-shadow-blur'], $option, false ),
							$option
						);
					}
					?>
				</select>
			</label>
			<label style='display: none'>
				Shadow Color
				<input class="tf-font-sel-shadow-color" type="text" value="<?php echo esc_attr( $value['text-shadow-color'] ) ?>" data-default-color="<?php echo esc_attr( $value['text-shadow-color'] ) ?>" />
			</label>
			<label style='display: none'>
				Shadow Opacity
				<select class='tf-font-sel-opacity'>
					<?php
					$options = array( '1', '0.9', '0.8', '0.7', '0.6', '0.5', '0.4', '0.3', '0.2', '0.1', '0' );
					foreach ( $options as $option ) {
						printf( "<option value='%s'%s>%s</option>",
							esc_attr( $option ),
							selected( $value['text-shadow-opacity'], $option, false ),
							$option
						);
					}
					?>
				</select>
			</label>
		</div>
		<?php


		$visibilityAttrs = '';
		if ( !$this->settings['show_preview'] ) {
			$visibilityAttrs = "data-visible='false' style='display: none'";
		}
		?>
		<div <?php echo ent2ncr( $visibilityAttrs ) ?>>
			<iframe data-preview-text='<?php echo esc_attr( $this->settings['preview_text'] ) ?>'></iframe>
			<i class='dashicons dashicons-admin-appearance btn-dark'></i>
			<input type='hidden' class='tf-font-sel-dark' value='<?php echo esc_attr( $value['dark'] ? 'dark' : '' ) ?>' />
		</div>
		<?php

		if ( !is_serialized( $value ) ) {
			$value = serialize( $value );
		}

		printf( "<input type='hidden' class='tf-for-saving' name='%s' id='%s' value='%s' />",
			$this->getID(),
			$this->getID(),
			esc_attr( $value )
		);

		$this->echoOptionFooter( false );
	}


	/**
	 * Cleans up the serialized value before saving
	 *
	 * @param    string $value The serialized value
	 *
	 * @return    string The cleaned value
	 * @since    1.4
	 */
	public function cleanValueForSaving( $value ) {
		if ( is_array( $value ) ) {
			$value = serialize( $value );
		}
		return stripslashes( $value );
	}


	/**
	 * Cleans the raw value for getting
	 *
	 * @param    string $value The raw value
	 *
	 * @return    string The cleaned value
	 * @since    1.4
	 */
	public function cleanValueForGetting( $value ) {
		if ( is_string( $value ) ) {
			if ( is_serialized( stripslashes( $value ) ) ) {
				$value = unserialize( $value );
			}
		}
		if ( is_array( $value ) ) {
			$value = array_merge( self::$defaultStyling, $value );
		}
		if ( !empty( $value['font-family'] ) ) {
			$value['font-type'] = in_array( $value['font-family'], array_keys( self::$webSafeFonts ) ) ? 'websafe' : 'google';
		}
		return $value;
	}


	/**
	 * Registers the theme customizer control, for displaying the option
	 *
	 * @param    WP_Customize                    $wp_enqueue_script The customize object
	 * @param    TitanFrameworkCustomizerSection $section           The section where this option will be placed
	 * @param    int                             $priority          The order of this control in the section
	 *
	 * @return    void
	 * @since    1.4
	 */
	public function registerCustomizerControl( $wp_customize, $section, $priority = 1 ) {
		$wp_customize->add_control( new TitanFrameworkOptionFontColorControl( $wp_customize, $this->getID(), array(
			'label'       => $this->settings['name'],
			'section'     => $section->settings['id'],
			'settings'    => $this->getID(),
			'description' => $this->settings['desc'],
			'priority'    => $priority,
			'params'      => $this->settings,
		) ) );
	}
}


/*
 * We create a new control for the theme customizer
 */
add_action( 'customize_register', 'registerTitanFrameworkOptionFontColorControl', 1 );


/**
 * Creates the option for the theme customizer
 *
 * @return    void
 * @since    1.4
 */
function registerTitanFrameworkOptionFontColorControl() {
	class TitanFrameworkOptionFontColorControl extends WP_Customize_Control {
		public $description;
		public $params;

		public function render_content() {
			$this->params['show_preview'] = false;
			TitanFrameworkOptionFontColor::createFontScript();

			?>
			<div class='tf-font'>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php

				// Get the current value and merge with defaults
				$value = $this->value();
				if ( is_serialized( $value ) ) {
					$value = unserialize( $value );
				}
				if ( !is_array( $value ) ) {
					$value = array();
				}
				$value = array_merge( TitanFrameworkOptionFontColor::$defaultStyling, $value );


				/*
				 * Create all the fields
				 */
				$visibilityAttrs = '';
				if ( !$this->params['show_font_family'] ) {
					$visibilityAttrs = "data-visible='false' style='display: none'";
				}
				?>
				<div>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Font Family
						<select class='tf-font-sel-family chosen-select'>
							<optgroup label="Web Safe Fonts" class='safe'>
								<?php
								foreach ( TitanFrameworkOptionFontColor::$webSafeFonts as $family => $label ) {
									printf( "<option value='%s'%s>%s</option>",
										$family,
										selected( $value['font-family'], $family, false ),
										$label
									);
								}
								?>
							</optgroup>
							<optgroup label="Google WebFonts" class='google'>
								<?php
								$allFonts = titan_get_googlefonts();
								foreach ( $allFonts as $key => $fontStuff ) {
									printf( "<option value='%s'%s>%s</option>",
										esc_attr( $fontStuff['name'] ),
										selected( $value['font-family'], $fontStuff['name'], false ),
										$fontStuff['name']
									);
								}
								?>
							</optgroup>
						</select>
					</label>
					<?php


					$visibilityAttrs = '';
					if ( !$this->params['show_color'] ) {
						$visibilityAttrs = "data-visible='false' style='display: none'";
					}
					?>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Color
						<input class='tf-font-sel-color color-picker-hex' type="text" value="<?php echo esc_attr( $value['color-opacity'] ) ?>" data-default-color="<?php echo esc_attr( $value['color-opacity'] ) ?>" />
					</label>
					<?php


					$visibilityAttrs = '';
					if ( !$this->params['show_font_size'] ) {
						$visibilityAttrs = "data-visible='false' style='display: none'";
					}
					?>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Font Size
						<select class='tf-font-sel-size'>
							<?php
							for ( $i = 1; $i <= 150; $i ++ ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $i . 'px' ),
									selected( $value['font-size'], $i . 'px', false ),
									$i . 'px'
								);
							}
							?>
						</select>
					</label>
					<?php


					$visibilityAttrs = '';
					if ( !$this->params['show_font_weight'] ) {
						$visibilityAttrs = "data-visible='false' style='display: none'";
					}
					?>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Font Weight
						<select class='tf-font-sel-weight'>
							<?php
							$options = array( 'normal', 'bold', 'bolder', 'lighter', '100', '200', '300', '400', '500', '600', '700', '800', '900' );
							foreach ( $options as $option ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $option ),
									selected( $value['font-weight'], $option, false ),
									$option
								);
							}
							?>
						</select>
					</label>
					<?php


					$visibilityAttrs = '';
					if ( !$this->params['show_font_style'] ) {
						$visibilityAttrs = "data-visible='false' style='display: none'";
					}
					?>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Font Style
						<select class='tf-font-sel-style'>
							<?php
							$options = array( 'normal', 'italic' );
							foreach ( $options as $option ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $option ),
									selected( $value['font-style'], $option, false ),
									$option
								);
							}
							?>
						</select>
					</label>
					<?php


					$visibilityAttrs = '';
					if ( !$this->params['show_line_height'] ) {
						$visibilityAttrs = "data-visible='false' style='display: none'";
					}
					?>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Line Height
						<select class='tf-font-sel-height'>
							<?php
							for ( $i = .5; $i <= 3; $i += 0.1 ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $i . 'em' ),
									selected( $value['line-height'], $i . 'em', false ),
									$i . 'em'
								);
							}
							?>
						</select>
					</label>
					<?php


					$visibilityAttrs = '';
					if ( !$this->params['show_letter_spacing'] ) {
						$visibilityAttrs = "data-visible='false' style='display: none'";
					}
					?>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Letter Spacing
						<select class='tf-font-sel-spacing'>
							<option value='normal'>normal</option>
							<?php
							for ( $i = - 20; $i <= 20; $i ++ ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $i . 'px' ),
									selected( $value['letter-spacing'], $i . 'px', false ),
									$i . 'px'
								);
							}
							?>
						</select>
					</label>
					<?php


					$visibilityAttrs = '';
					if ( !$this->params['show_text_transform'] ) {
						$visibilityAttrs = "data-visible='false' style='display: none'";
					}
					?>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Text Transform
						<select class='tf-font-sel-transform'>
							<?php
							$options = array( 'none', 'capitalize', 'uppercase', 'lowercase' );
							foreach ( $options as $option ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $option ),
									selected( $value['text-transform'], $option, false ),
									$option
								);
							}
							?>
						</select>
					</label>
					<?php


					$visibilityAttrs = '';
					if ( !$this->params['show_font_variant'] ) {
						$visibilityAttrs = "data-visible='false' style='display: none'";
					}
					?>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Font Variant
						<select class='tf-font-sel-variant'>
							<?php
							$options = array( 'normal', 'small-caps' );
							foreach ( $options as $option ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $option ),
									selected( $value['font-variant'], $option, false ),
									$option
								);
							}
							?>
						</select>
					</label>
					<?php


					$visibilityAttrs = '';
					if ( !$this->params['show_text_shadow'] ) {
						$visibilityAttrs = "data-visible='false' style='display: none'";
					}
					?>
					<label <?php echo ent2ncr( $visibilityAttrs ) ?>>
						Shadow Location
						<select class='tf-font-sel-location'>
							<?php
							$options = array( 'none', 'top', 'bottom', 'left', 'right', 'top-left', 'top-right', 'bottom-left', 'bottom-right' );
							foreach ( $options as $option ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $option ),
									selected( $value['text-shadow-location'], $option, false ),
									$option
								);
							}
							?>
						</select>
					</label>
					<label style='display: none'>
						Shadow Distance
						<select class='tf-font-sel-distance'>
							<?php
							for ( $i = 0; $i <= 10; $i ++ ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $i . 'px' ),
									selected( $value['text-shadow-distance'], $i . 'px', false ),
									$i . 'px'
								);
							}
							?>
						</select>
					</label>
					<label style='display: none'>
						Shadow Blur
						<select class='tf-font-sel-blur'>
							<?php
							$options = array( '0px', '1px', '2px', '3px', '4px', '5px', '10px', '20px' );
							foreach ( $options as $option ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $option ),
									selected( $value['text-shadow-blur'], $option, false ),
									$option
								);
							}
							?>
						</select>
					</label>
					<label style='display: none'>
						Shadow Color
						<input class="tf-font-sel-shadow-color" type="text" value="<?php echo esc_attr( $value['text-shadow-color'] ) ?>" data-default-color="<?php echo esc_attr( $value['text-shadow-color'] ) ?>" />
					</label>
					<label style='display: none'>
						Shadow Opacity
						<select class='tf-font-sel-opacity'>
							<?php
							$options = array( '1', '0.9', '0.8', '0.7', '0.6', '0.5', '0.4', '0.3', '0.2', '0.1', '0' );
							foreach ( $options as $option ) {
								printf( "<option value='%s'%s>%s</option>",
									esc_attr( $option ),
									selected( $value['text-shadow-opacity'], $option, false ),
									$option
								);
							}
							?>
						</select>
					</label>
				</div>
				<?php


				$visibilityAttrs = '';
				if ( !$this->params['show_preview'] ) {
					$visibilityAttrs = "data-visible='false' style='display: none'";
				}
				?>
				<div <?php echo ent2ncr( $visibilityAttrs ) ?>>
					<iframe></iframe>
					<i class='dashicons dashicons-admin-appearance btn-dark'></i>
					<input type='hidden' class='tf-font-sel-dark' value='<?php echo esc_attr( $value['dark'] ? 'dark' : '' ) ?>' />
				</div>
				<?php

				if ( !is_serialized( $value ) ) {
					$value = serialize( $value );
				}

				?>
				<input type='hidden' class='tf-for-saving' <?php $this->link() ?> value='<?php echo esc_attr( $value ) ?>' />
			</div>
			<?php
			echo "<p class='description'>{$this->description}</p>";
		}
	}
}
